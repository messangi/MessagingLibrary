# MessagingLibrary

[![CI Status](https://img.shields.io/badge/build-v1.0.0-blue)](https://git.messangi.com/messangi/messangi-ios-sdk)
[![Version](https://img.shields.io/cocoapods/v/MessangiSDK.svg?style=flat)](https://cocoapods.org/pods/MessangiSDK)
[![License](https://img.shields.io/cocoapods/l/MessangiSDK.svg?style=flat)](https://cocoapods.org/pods/MessangiSDK)
[![Platform](https://img.shields.io/cocoapods/p/MessangiSDK.svg?style=flat)](https://cocoapods.org/pods/MessangiSDK)

## Description

---
It is a tool that allows you to add the following functionalities to your solution

- Send notifications through Messangi Services.
- Functionality to enable and disable notifications by the user.
- Register device characteristics (UUID, Type, Language, OS Version, Model)
- Associate labels to the device
- Record customizable user information
- Deeplinks Handler

## Requirements

---
To use the Messaging Library is required:

- A registered apple account in the development program.
- Follow the 3 steps for installation.

## Let's stared

### Step 1: Configure e prepare CocoaPod

Open terminal and start CodoaPod on the project you are working on.

```bash
cd /YourProject
pod init
nano Podfile
```

Place the "MessagingLibrary" dependency

```bash
pod 'MessagingLibrary'
```

Run the installation or update command as appropriate.

```bash
pod install
# or
pod update
```

Open the workspace created by cocoapod for your project

```bash
open YourProject.xcworkspace
```

### Step 2: Configure XCode Project

Select your project and go to the **Signatures and Capabilities** tab, select a valid device to configure the following Capabilities:

- Add Push notifications.
- Add Background modes and enable:
  - Location updates
  - Background procesing
  - Remote notifications
- Add Keychain Sharing and set a keychain group name:

```swift
  com.messaging.MessagingLibrary
```

[![ProjectXCodeSettings]](https://git.messangi.com/messangi/messangi-ios-sdk/-/raw/master/Screenshots/ProjectXCodeSettings.jpg)

- Add the configuration file [Messaging-Info.plist](https://git.messangi.com/messangi/messangi-ios-sdk/-/raw/master/Example/MessangiSDK/Messangi-Info.plist) and put the following values.
  - *messagingHost* string: it must contain the url and the host version of messaging.
  - *messagingAppToken* string: access code granted by messaging.
  - *loggingEnable* boolean: variable to activate or not the logs from the sdk.
  - *locationEnable* boolean: variable to activate or not the location use in the sdk.
  - *analyticsEnable* boolean: variable to activate or not the analytics use in the sdk.

[![MessangiConfigFile]](https://git.messangi.com/messangi/messangi-ios-sdk/-/raw/master/Screenshots/MessangiConfigFile.jpg)

### Step 3: Open the AppDelegate file of your project

To do this, modify your delegate app with the following imports and methods

```swift
 import MessagingLibrary
 @UIApplicationMain
 class AppDelegate: MessagingAppDelegate {

    // It is executed when the user interacts with a notification.
    override func messagingInteractionNotification(_ notification: MessagingNotification) {
       // your code
    }

    // It is executed when a notification is received which allows operations to be performed without user interaction.
    override func messagingReceivedNotification(_ notification: MessagingNotification) -> UNNotificationPresentationOptions {
        // your code
        // if true
        //   return [.alert, .sound] // shows the notification on foreground.
        // else
        //   return [] // does not show the foreground notification.
        return [.alert, .sound] // for this example it will always be shown.
    }

    // Requesting permissions to receive notifications when you open the app by overwriting the messagingDidInitialized function inherited from MessagingAppDelegate.
    override func messagingDidInitialized(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]?) -> Bool {
        // utility to request permissions to receive notifications
        Messaging.shared.userNotification.requestPermissionForPushNotifications()
        return true
    }
 }
...
```

There are 2 types of implementation (explicit and implicit), for its simplicity and to start quickly we will use the implicit implementation of the SDK as well as requesting permissions to the user to receive notifications when opening the application, we will also implement the methods **messagingReceivedNotification** and **messagingInteractionNotification**.

Ready!, you can now run your project, accept the permissions to receive notifications and use the push token that APNS assigns you to send notifications using our.

**Note:**  remember to activate the logs in the configuration file indicated in step 2, so you can see in the console the push token that assigns you APNS and copy it easily.

## Usage

To make use of the functionalities that Messaging Library offers, the Messaging class is available, to obtain an instance of this class you can do.

```swift
let messaging = Messaging.shared
```

By doing this you have access to

```swift
Messaging.shared.userNotification.requestPermissionForPushNotifications()
Messaging.shared.fetchDevice(forceCallToService:)
Messaging.shared.fetchUser(forceCallToService:)
Messaging.shared.observe\EventName/
Messaging.shared.removeObserve\EventName/
```

## Example - Getting a MessagingNotification (willPresent)

This way it will process all the notifications that arrive at the device, whether they are in background or foreground, regardless of whether the user interacts with them.

```swift
...
import MessagingLibrary

@UIApplicationMain
class AppDelegate: MessagingAppDelegate or ... MessagingUserNotificationDelegate {

    override func messagingReceivedNotification(_ notification: MessagingNotification) -> UNNotificationPresentationOptions {
       ...
       // your code
       // notification.actionIdentifier // has your custom action identifier
    }
}
```

Another way to process notifications is through an observer.

```swift
...
import MessagingLibrary

class ExampleViewController: UIViewController {
    ...
    private var ReceivedNotification: MessagingNotification?

    override func viewDidLoad() {
       ...
        _ = Messaging.shared.observeReceivedNotification(self, do: #selector(workWithUser(_:)))
       ...
    }
    // Unlike the previous examples, this case does not require a request for notification since the notification is executed at the moment it is received.
    @objc func workWithNotification( _ notification: Notification){
        if let messagingNotification = notification.object as? MessagingNotification {
            // MessagingNotification availability
            self.ReceivedNotification = messagingNotification
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
       ...
        _ = Messangi.shared.removeObserveReceivedNotification(self)
       ...
    }
}
```

## Example -  To control the interaction of the notification (didReceive)

This method will only run when the user of the device presses the notification.

```swift
...
import MessagingLibrary

@UIApplicationMain
class AppDelegate: MessagingAppDelegate or ... MessagingUserNotificationDelegate {

    override func messagingInteractionNotification(_ notification: MessagingNotification) {
       ...
       // your code
       // notification.actionIdentifier // has your custom action identifier
    }
}
```

## Example - Getting MessagingDevice

```swift
...
import MessagingLibrary

class ExampleViewController: UIViewController {
    ...
    private var device: MessagingDevice?

    override func viewDidLoad() {
       ...
        _ = Messaging.shared.observeDeviceFetchResponse(self, do: #selector(workWithDevice(_:)))
       ...
    }

    func onAnyEventToGetDevice(){
        Messaging.shared.fetchDevice()
    }

    @objc func workWithDevice( _ notification: Notification){
        if let device = notification.object as? MessagingDevice {
            // MessagingDevice availability
            self.device = device
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
       ...
        _ = Messaging.shared.removeObserveDeviceFetchResponse(self)
       ...
    }
}
```

## Example - Getting MessagingUser

```swift
...
import MessagingLibrary

class ExampleViewController: UIViewController {
    ...
    private var user: MessagingUser?

    override func viewDidLoad() {
       ...
        _ = Messaging.shared.observeUserFetchResponse(self, do: #selector(workWithUser(_:)))
       ...
    }

    func onAnyEventToGetUser(){
        // Need MessagingDevice
        Messaging.shared.fetchUser()
    }

    @objc func workWithUser( _ notification: Notification){
        if let user = notification.object as? MessagingUser {
            // MessagingUser availability
            self.user = user
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
       ...
        _ = Messangi.shared.removeObserveUserFetchResponse(self)
       ...
    }
}
```

## Deeplinks

MessagingLibrary also allows for notifications or a link on a web page or other application to interact with your application.

For this we have 3 modalities: Explicit behavior using Payload, using URL Schema or Universal Links.

### - Payload

For this you only have to indicate what the behavior will be once a notification of this type is received, in the following way:

```swift
...
import MessagingLibrary

@UIApplicationMain
class AppDelegate: MessagingAppDelegate or ... MessagingUserNotificationDelegate {

    ...
    override func messagingReceivedDeeplink(_ notification: MessagingNotification) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        if  let root = window?.rootViewController as? UINavigationController,
            let detail = storyboard.instantiateViewController(withIdentifier: "detailVCId") as? NotificationDetailViewController {
            detail.notification = notification
            root.pushViewController(detail, animated: true)
        }
    }
    ...
}
```

- In this example, we ask if the root view of the application is a navigation controller and we look in the *Main.storyboard* file for a view controller that has the *detailVCId* identifier, if both premises are correct. You pass the *notification* parameter to make use of the data within the definition of my class *NotificationDetailViewController* and you place this screen for the user to visualize it.
- **MessagingReceivedDeeplink** is a function that is invoked when a notification of type deeplink is received and is found in MessagingAppDelegate or MessagingUserNotificationDelegate, the idea is to define what to do with the overwriting of this method. **Note:** For the execution of this method, the user is required to interact with the notification, so it must be shown on the screen with the function **messagingReceivedNotification**

```swift
@UIApplicationMain
class AppDelegate: MessagingAppDelegate or ... MessagingUserNotificationDelegate {
    ...
    override func messagingReceivedNotification(_ notification: MessagingNotification, window: UIWindow?)
        -> UNNotificationPresentationOptions {
        if notification.deeplink {
            return [.alert, .sound]
        }
    }
    ...
}
```

- In this example, if a deeplink notification is received, it is displayed on the screen.

### - URL Schema

A linking scheme allows you to associate a link with your application. This approach uses the linking scheme to determine which application is linked to that scheme. Once configured, you will have a link that will open your application and process this link as appropriate.

to associate a url scheme to your application you have to open your project settings, Info tab, URL types section

[![ConfigURLTypes]](https://git.messangi.com/messangi/messangi-ios-sdk/-/raw/master/Screenshots/ConfigURLTypes.png)

This is an example of a linking scheme:
yourapp://sectionapp?param1=value1&...&paramN=valueN

You can use this link in some website or using the push notifications, indicate that it is a deeplink notification and put the link in an attribute called schema, optionally you can put other parameters of interest since these will be added to the url when processing it, this way

Example: Web Site

```html
...
  <a href="yourapp://sectionapp?param1=value1&...&paramN=valueN">See more</a>
...
```

Example: Push Notification Data

```json
...
"data": {
  "deeplink": true,
  "schema": "yourapp://sectionapp?param1=value1&...&paramN=valueN",
  "another1": "value1",
  ...
  "anotherX": "valueX"
}
```

The method is used to indicate the behavior that will be done to process the url:

```swift
func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:], window: UIWindow?) -> Bool {
    // your code
    // example: open your view controller using the data url.
    return true
}

```

Now all the information received by the url can be extracted from the url object, or if you wish you could use another structure like NSURLComponents to support the methods you have and obtain the path or the query parameters

In this example, we use NSURLComponents to extract the information from the url and place it in a dictionary.

```swift
var urlData:[String: Any?] = [:]
urlData["url.absoluteString"] = url.absoluteString
if let components = NSURLComponents(url: url, resolvingAgainstBaseURL: true){
    urlData["path"] = components.path
    var params:[String: Any?] = [:]
    for param in components.queryItems ?? [] {
        params[param.name] = param.value
    }
    urlData["queryItems"] = params
}
```

You can refer to the full example to observe this behavior.

### - Universal Link

Note: remember that for the deep links through push notification to work, they need to be displayed on screen so the user can click on it, when the app is in background this is controlled by the operating system but when it is in foreground you must do this with the messagingReceivedNotification method and return the display options [.alert, .sound].

```swift
    ...
    func messagingReceivedNotification(_ notification: MessagingNotification, window: UIWindow?)
        -> UNNotificationPresentationOptions {
        if notification.deeplink {
            return [.alert, .sound]
        }
    }
    ...
```

## Example - Full example

You are in the following repository, you should just clone the repository, have the library at the same level of the project and open the file FullDemonstrationMessagingLibrary.xcworkspace, I leave some screenshots of the application.

[![ScreenshotsIphone]](https://git.messangi.com/messangi/messangi-ios-sdk/-/raw/master/Screenshots/ScreenshotsIphone.jpg)

### What options do you have to implement MessagingLibrary in your project

#### Implicit Implementation

Open your AppDelegate *import MessagingLibrary* module and replace parent class *UIResponder* and implementation *UIApplicationDelegate* with *MessagingAppDelegate*

```swift
import MessagingLibrary
@UIApplicationMain
class AppDelegate: MessagingAppDelegate {
   // you can leave this empty if you're using a storyboard.
}
```

**Note:** you can overwrite the MessagingAppDelegate methods in your AppDelegate, but remember to invoke the parent via **super**.

```swift
@UIApplicationMain
class AppDelegate: MessagingAppDelegate {
   override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]?) -> Bool {
     // your code
     return super.application(application, didFinishLaunchingWithOptions: launchOptions)
   }
}
```

#### Explicit application

If you cannot do without the current parent class of your project, place the following invocations in the following methods of your AppDelegate.

In the applicationDidFinishLaunchingWithOptions method place MessagingImplementation.initialize(), in this manner.

```swift
override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    MessagingImplementation.initialize()
    // your code...
    return true
}
```

In the applicationDidRegisterForRemoteNotificationsWithDeviceToken method place MessagingImplementation.indicate(pushToken: deviceToken), in this manner.

```swift
override func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    MessagingImplementation.indicate(pushToken: deviceToken)
}
```

And in the applicationWillEnterForeground method place MessagingImplementation.checkChanges(), in this manner.

```swift
override func applicationWillEnterForeground(_ application: UIApplication) {
    MessagingImplementation.checkChanges()
}
```

Also in method application(_:didReceiveRemoteNotification:fetchCompletionHandler) place MessagingImplementation.didReceiveRemoteNotification(_:fetchCompletionHandler), in this way.

```swift
func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
    MessagingngImplementation.didReceiveRemoteNotification(userInfo, fetchCompletionHandler: completionHandler)
}
```

Finally you can implement the MessagingNotificationDelegate interface in your AppDelegate class to manage what happens when a notification arrives.

```swift
...
 class AppDelegate: ..., MessagingNotificationDelegate {
     ...
 }
...
```

**Note:** Remember that in order to receive notifications you must request permissions from the user, this can be done using this function and this will be done when an event is developed (when starting the application or when tapping on any component of the interface)

```swift
...
 class AppDelegate: MessagingAppDelegate {
    /// Example 1: Requesting permission to receive notifications when you open the app by overwriting the application:didFinishLaunchingWithOptions function.
    override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]?) -> Bool {
        // utility to request permissions to receive notifications
        Messaging.shared.userNotification.requestPermissionForPushNotifications()
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
 }
...
```

```swift
...
 class AppDelegate: MessagingAppDelegate {
     // Example 2: Requesting permissions to receive notifications when you open the app by overwriting the messagingDidInitialized function inherited from MessagingAppDelegate.
    override func messagingDidInitialized(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]?) -> Bool {
        // utility to request permissions to receive notifications
        Messaging.shared.userNotification.requestPermissionForPushNotifications()
        return true
    }
 }
...
```

```swift
...
 class MyGUIViewController: UIViewController {
     ...
     @IBAction func onTapRequestPermissionForPushNotifications(_ sender: Any) {
        // utility to request permissions to receive notifications
        Messaging.shared.userNotification.requestPermissionForPushNotifications()
    }
     ...
 }
...
```

## Author

Messangi

## License

Messangi is available under the MIT license. See the LICENSE file for more info.
